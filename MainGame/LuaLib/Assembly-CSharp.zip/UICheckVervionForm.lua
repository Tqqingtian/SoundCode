---@class UICheckVervionForm : TQ.UIFormBase
local m = {}

UICheckVervionForm = m
return m
