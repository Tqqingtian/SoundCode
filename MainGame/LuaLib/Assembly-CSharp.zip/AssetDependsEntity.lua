---@class AssetDependsEntity : System.Object
---@field public Category AssetCategory
---@field public AssetFullName string
local m = {}

AssetDependsEntity = m
return m
