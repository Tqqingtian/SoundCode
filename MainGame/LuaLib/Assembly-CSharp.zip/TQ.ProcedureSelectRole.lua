---@class TQ.ProcedureSelectRole : TQ.ProcedureBase
local m = {}

TQ.ProcedureSelectRole = m
return m
