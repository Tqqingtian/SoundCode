---@class Sys_SoundDBModel : TQ.DataTableDBModelBase_2_Sys_SoundDBModel_Sys_SoundEntity_
---@field public DataTableName string
local m = {}

Sys_SoundDBModel = m
return m
