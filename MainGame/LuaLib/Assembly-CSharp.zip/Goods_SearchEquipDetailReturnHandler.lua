---@class Goods_SearchEquipDetailReturnHandler : System.Object
local m = {}

---@static
---@param buffer string
function m.OnGoods_SearchEquipDetailReturn(buffer) end

Goods_SearchEquipDetailReturnHandler = m
return m
