---@class ReallySimpleAudioSpawner._Spawner_d__6 : System.Object
---@field public <>4__this ReallySimpleAudioSpawner
local m = {}

ReallySimpleAudioSpawner._Spawner_d__6 = m
return m
