---@class UIMultiScrollIndex : UnityEngine.MonoBehaviour
---@field public Index number
---@field public Scroller UIMultiScroller
local m = {}

UIMultiScrollIndex = m
return m
