---@class TestProcedure : UnityEngine.MonoBehaviour
local m = {}

TestProcedure = m
return m
