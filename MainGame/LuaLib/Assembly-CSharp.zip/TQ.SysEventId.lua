---@class TQ.SysEventId : System.Object
---@field public LoadDataTableComplete number @static
---@field public LoadOneDataTableComplete number @static
---@field public LoadLuaDataTableComplete number @static
---@field public LoadingProgressChange number @static
---@field public CheckVersionBeginDownload number @static
---@field public CheckVersionBeginDownloadUpdate number @static
---@field public CheckVersionBeginDownloadComplete number @static
---@field public PreloadBegin number @static
---@field public PreloadUpdate number @static
---@field public PreloadComplete number @static
---@field public CloseCheckVersionUI number @static
local m = {}

TQ.SysEventId = m
return m
