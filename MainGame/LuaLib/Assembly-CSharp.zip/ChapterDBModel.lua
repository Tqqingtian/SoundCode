---@class ChapterDBModel : TQ.DataTableDBModelBase_2_ChapterDBModel_ChapterEntity_
---@field public DataTableName string
local m = {}

ChapterDBModel = m
return m
