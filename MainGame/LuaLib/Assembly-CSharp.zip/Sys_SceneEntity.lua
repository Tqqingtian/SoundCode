---@class Sys_SceneEntity : TQ.DataTableEntityBase
---@field public SceneName string
---@field public BGMId number
---@field public SceneType number
local m = {}

Sys_SceneEntity = m
return m
