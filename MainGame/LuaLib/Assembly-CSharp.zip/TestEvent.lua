---@class TestEvent : UnityEngine.MonoBehaviour
local m = {}

TestEvent = m
return m
