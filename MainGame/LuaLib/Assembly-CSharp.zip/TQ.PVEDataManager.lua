---@class TQ.PVEDataManager : System.Object
local m = {}

function m:Clear() end

---@virtual
function m:Dispose() end

TQ.PVEDataManager = m
return m
