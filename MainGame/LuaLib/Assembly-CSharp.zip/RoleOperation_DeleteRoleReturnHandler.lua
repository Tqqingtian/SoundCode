---@class RoleOperation_DeleteRoleReturnHandler : System.Object
local m = {}

---@static
---@param buffer string
function m.OnRoleOperation_DeleteRoleReturn(buffer) end

RoleOperation_DeleteRoleReturnHandler = m
return m
