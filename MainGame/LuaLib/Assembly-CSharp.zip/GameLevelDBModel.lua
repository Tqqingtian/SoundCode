---@class GameLevelDBModel : TQ.DataTableDBModelBase_2_GameLevelDBModel_GameLevelEntity_
---@field public DataTableName string
local m = {}

GameLevelDBModel = m
return m
