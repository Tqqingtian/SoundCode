---@class TQ.Variable_1_UnityEngine_Transform_ : TQ.VariableBase
---@field public Value UnityEngine.Transform
---@field public Type System.Type
local m = {}

TQ.Variable_1_UnityEngine_Transform_ = m
return m
