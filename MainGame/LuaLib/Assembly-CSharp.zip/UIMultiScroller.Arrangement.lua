---@class UIMultiScroller.Arrangement : System.Enum
---@field public Horizontal UIMultiScroller.Arrangement @static
---@field public Vertical UIMultiScroller.Arrangement @static
---@field public value__ number
local m = {}

UIMultiScroller.Arrangement = m
return m
