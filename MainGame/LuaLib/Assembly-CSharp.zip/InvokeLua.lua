---@class InvokeLua : UnityEngine.MonoBehaviour
local m = {}

InvokeLua = m
return m
