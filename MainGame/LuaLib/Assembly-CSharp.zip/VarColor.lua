---@class VarColor : UnityEngine.MonoBehaviour
local m = {}

VarColor = m
return m
