---@class LoadingType : System.Enum
---@field public CheckVersion LoadingType @static
---@field public ChangeScene LoadingType @static
---@field public value__ number
local m = {}

LoadingType = m
return m
