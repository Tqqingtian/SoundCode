---@class Tutorial.DerivedClass.__c : System.Object
---@field public <>9 Tutorial.DerivedClass.__c @static
---@field public <>9__6_0 fun() @static
---@field public <>9__22_0 fun(obj:string) @static
local m = {}

Tutorial.DerivedClass.__c = m
return m
