---@class Goods_EquipPutReturnHandler : System.Object
local m = {}

---@static
---@param buffer string
function m.OnGoods_EquipPutReturn(buffer) end

Goods_EquipPutReturnHandler = m
return m
