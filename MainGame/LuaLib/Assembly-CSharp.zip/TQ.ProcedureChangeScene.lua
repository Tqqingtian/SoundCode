---@class TQ.ProcedureChangeScene : TQ.ProcedureBase
local m = {}

TQ.ProcedureChangeScene = m
return m
