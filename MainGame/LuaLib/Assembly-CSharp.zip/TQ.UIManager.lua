---@class TQ.UIManager : TQ.ManagerBase
local m = {}

---@param uiformId number
---@return boolean
function m:IsExists(uiformId) end

TQ.UIManager = m
return m
