---@class TQ.AssetBundleInfoEntity : System.Object
---@field public AssetBundleName string
---@field public MD5 string
---@field public Size number
---@field public IsFirstData boolean
---@field public IsEncrypt boolean
local m = {}

TQ.AssetBundleInfoEntity = m
return m
