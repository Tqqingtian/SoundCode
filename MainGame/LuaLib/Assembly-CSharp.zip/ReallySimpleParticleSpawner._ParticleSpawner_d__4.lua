---@class ReallySimpleParticleSpawner._ParticleSpawner_d__4 : System.Object
---@field public <>4__this ReallySimpleParticleSpawner
local m = {}

ReallySimpleParticleSpawner._ParticleSpawner_d__4 = m
return m
