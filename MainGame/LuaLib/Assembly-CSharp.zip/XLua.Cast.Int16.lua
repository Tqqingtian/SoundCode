---@class XLua.Cast.Int16 : XLua.Cast.Any_1_System_Int16_
local m = {}

XLua.Cast.Int16 = m
return m
