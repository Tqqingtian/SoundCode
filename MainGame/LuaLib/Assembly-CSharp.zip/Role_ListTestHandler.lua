---@class Role_ListTestHandler : System.Object
local m = {}

---@static
---@param buffer string
function m.OnRole_ListTest(buffer) end

Role_ListTestHandler = m
return m
