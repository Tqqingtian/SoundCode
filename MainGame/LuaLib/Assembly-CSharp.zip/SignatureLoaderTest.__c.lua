---@class SignatureLoaderTest.__c : System.Object
---@field public <>9 SignatureLoaderTest.__c @static
---@field public <>9__1_0 fun(filepath:System.String):(, System.String) @static
local m = {}

SignatureLoaderTest.__c = m
return m
