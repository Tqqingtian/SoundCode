---@class CoroutineConfig : System.Object
---@field public LuaCallCSharp System.Type[] @static
local m = {}

CoroutineConfig = m
return m
