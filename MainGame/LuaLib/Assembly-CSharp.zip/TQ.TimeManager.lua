---@class TQ.TimeManager : TQ.ManagerBase
local m = {}

---@virtual
function m:Dispose() end

TQ.TimeManager = m
return m
