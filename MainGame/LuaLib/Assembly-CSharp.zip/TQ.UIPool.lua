---@class TQ.UIPool : System.Object
local m = {}

TQ.UIPool = m
return m
