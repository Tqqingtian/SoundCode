---@class SkillLevelDBModel : TQ.DataTableDBModelBase_2_SkillLevelDBModel_SkillLevelEntity_
---@field public DataTableName string
local m = {}

SkillLevelDBModel = m
return m
