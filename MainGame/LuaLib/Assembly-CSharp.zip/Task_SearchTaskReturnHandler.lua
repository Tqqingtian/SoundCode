---@class Task_SearchTaskReturnHandler : System.Object
local m = {}

---@static
---@param buffer string
function m.OnTask_SearchTaskReturn(buffer) end

Task_SearchTaskReturnHandler = m
return m
