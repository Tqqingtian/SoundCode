---@class SecurityUtil : System.Object
local m = {}

---@static
---@param buffer string
---@return string
function m.Xor(buffer) end

SecurityUtil = m
return m
