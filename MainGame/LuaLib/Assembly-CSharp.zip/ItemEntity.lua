---@class ItemEntity : TQ.DataTableEntityBase
---@field public Name string
---@field public Type number
---@field public UsedLevel number
---@field public UsedMethod string
---@field public SellMoney number
---@field public Quality number
---@field public Description string
---@field public UsedItems string
---@field public maxAmount number
---@field public packSort number
local m = {}

ItemEntity = m
return m
