---@class GenericStruct_1_T_ : System.ValueType
local m = {}

---@param p number
---@return any
function m:GetA(p) end

GenericStruct_1_T_ = m
return m
