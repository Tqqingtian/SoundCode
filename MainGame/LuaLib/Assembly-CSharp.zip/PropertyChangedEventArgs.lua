---@class PropertyChangedEventArgs : System.EventArgs
---@field public name string
---@field public value any
local m = {}

PropertyChangedEventArgs = m
return m
