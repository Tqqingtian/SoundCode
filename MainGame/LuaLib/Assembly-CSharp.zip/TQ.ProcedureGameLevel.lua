---@class TQ.ProcedureGameLevel : TQ.ProcedureBase
local m = {}

TQ.ProcedureGameLevel = m
return m
