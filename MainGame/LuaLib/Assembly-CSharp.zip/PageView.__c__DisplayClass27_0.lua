---@class PageView.__c__DisplayClass27_0 : System.Object
---@field public go UnityEngine.GameObject
local m = {}

PageView.__c__DisplayClass27_0 = m
return m
