---@class TQ.ProcedureWordMap : TQ.ProcedureBase
local m = {}

TQ.ProcedureWordMap = m
return m
