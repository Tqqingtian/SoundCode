---@class CSCallLua.DClass : System.Object
---@field public f1 number
---@field public f2 number
local m = {}

CSCallLua.DClass = m
return m
