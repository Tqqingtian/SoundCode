---@class TestPool._CreateObj_d__5 : System.Object
---@field public <>4__this TestPool
local m = {}

TestPool._CreateObj_d__5 = m
return m
