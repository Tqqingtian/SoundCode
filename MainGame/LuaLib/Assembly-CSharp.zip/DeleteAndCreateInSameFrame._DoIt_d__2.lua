---@class DeleteAndCreateInSameFrame._DoIt_d__2 : System.Object
---@field public <>4__this DeleteAndCreateInSameFrame
local m = {}

DeleteAndCreateInSameFrame._DoIt_d__2 = m
return m
