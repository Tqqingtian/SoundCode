---@class SimpleSpawner._Spawner_d__8 : System.Object
---@field public <>4__this SimpleSpawner
local m = {}

SimpleSpawner._Spawner_d__8 = m
return m
