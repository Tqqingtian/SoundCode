---@class GameLevelRegionEntity : TQ.DataTableEntityBase
---@field public GameLevelId number
---@field public RegionId number
---@field public InitSprite string
local m = {}

GameLevelRegionEntity = m
return m
