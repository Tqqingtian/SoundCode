---@class AutoLoadTexture : UnityEngine.MonoBehaviour
---@field public ImgName string
---@field public ImgPath string
---@field public IsSetNativeSize boolean
local m = {}

function m:SetImg() end

AutoLoadTexture = m
return m
