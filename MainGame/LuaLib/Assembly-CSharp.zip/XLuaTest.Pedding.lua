---@class XLuaTest.Pedding : System.ValueType
---@field public c number
local m = {}

XLuaTest.Pedding = m
return m
