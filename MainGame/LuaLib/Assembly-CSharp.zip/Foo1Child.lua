---@class Foo1Child : Foo1Parent
local m = {}

Foo1Child = m
return m
