---@class HotfixTest2 : UnityEngine.MonoBehaviour
local m = {}

HotfixTest2 = m
return m
