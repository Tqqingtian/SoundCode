---@class SimpleSpawner._Despawner_d__9 : System.Object
---@field public <>4__this SimpleSpawner
local m = {}

SimpleSpawner._Despawner_d__9 = m
return m
