---@class UITaskFormItemView : UnityEngine.MonoBehaviour
local m = {}

---@param entity ServerTaskEntity
---@param onClik fun(obj:number)
function m:SetUI(entity, onClik) end

UITaskFormItemView = m
return m
