---@class ReallySimpleParticleSpawner : UnityEngine.MonoBehaviour
---@field public poolName string
---@field public prefab UnityEngine.ParticleSystem
---@field public spawnInterval number
local m = {}

ReallySimpleParticleSpawner = m
return m
