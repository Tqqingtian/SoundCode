---@class NoHotfixCalc : System.Object
local m = {}

---@param a number
---@param b number
---@return number
function m:Add(a, b) end

NoHotfixCalc = m
return m
