---@class TQ.TQImage : UnityEngine.UI.Image
local m = {}

TQ.TQImage = m
return m
