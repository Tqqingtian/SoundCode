---@class TestUI : UnityEngine.MonoBehaviour
local m = {}

TestUI = m
return m
