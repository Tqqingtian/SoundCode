---@class TQ.DataManager : TQ.ManagerBase
local m = {}

TQ.DataManager = m
return m
