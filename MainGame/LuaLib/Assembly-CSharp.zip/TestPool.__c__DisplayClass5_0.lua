---@class TestPool.__c__DisplayClass5_0 : System.Object
---@field public i number
---@field public <>4__this TestPool
local m = {}

TestPool.__c__DisplayClass5_0 = m
return m
