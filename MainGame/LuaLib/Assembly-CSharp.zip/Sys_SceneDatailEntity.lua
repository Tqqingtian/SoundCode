---@class Sys_SceneDatailEntity : TQ.DataTableEntityBase
---@field public SceneId number
---@field public ScenePath string
---@field public SceneGrade number
local m = {}

Sys_SceneDatailEntity = m
return m
