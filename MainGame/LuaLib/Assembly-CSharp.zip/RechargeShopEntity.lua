---@class RechargeShopEntity : TQ.DataTableEntityBase
---@field public Type number
---@field public Price number
---@field public Name string
---@field public SalesDesc string
---@field public ProductDesc string
---@field public Virtual number
---@field public Icon string
local m = {}

RechargeShopEntity = m
return m
