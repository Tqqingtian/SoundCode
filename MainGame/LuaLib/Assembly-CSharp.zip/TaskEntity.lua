---@class TaskEntity : TQ.DataTableEntityBase
---@field public Name string
---@field public Status number
---@field public Content string
local m = {}

TaskEntity = m
return m
