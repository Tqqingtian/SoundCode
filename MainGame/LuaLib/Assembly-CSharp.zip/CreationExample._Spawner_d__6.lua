---@class CreationExample._Spawner_d__6 : System.Object
---@field public <>4__this CreationExample
local m = {}

CreationExample._Spawner_d__6 = m
return m
