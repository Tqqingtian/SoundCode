---@class TestPool : UnityEngine.MonoBehaviour
---@field public tran1 UnityEngine.Transform
---@field public tran2 UnityEngine.Transform
local m = {}

TestPool = m
return m
