---@class MaterialDBModel : TQ.DataTableDBModelBase_2_MaterialDBModel_MaterialEntity_
---@field public DataTableName string
local m = {}

MaterialDBModel = m
return m
