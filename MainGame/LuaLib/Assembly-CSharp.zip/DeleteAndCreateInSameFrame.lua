---@class DeleteAndCreateInSameFrame : UnityEngine.MonoBehaviour
---@field public poolPrefab PathologicalGames.SpawnPool
local m = {}

DeleteAndCreateInSameFrame = m
return m
