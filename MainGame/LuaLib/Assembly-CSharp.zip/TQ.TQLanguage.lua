---@class TQ.TQLanguage : System.Enum
---@field public Chinese TQ.TQLanguage @static
---@field public English TQ.TQLanguage @static
---@field public value__ number
local m = {}

TQ.TQLanguage = m
return m
