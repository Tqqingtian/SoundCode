---@class HotfixTest2.__c : System.Object
---@field public <>9 HotfixTest2.__c @static
---@field public <>9__1_0 fun(arg1:number, arg2:number) @static
local m = {}

HotfixTest2.__c = m
return m
