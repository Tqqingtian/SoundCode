---@class CreationExample._Despawner_d__7 : System.Object
---@field public <>4__this CreationExample
local m = {}

CreationExample._Despawner_d__7 = m
return m
