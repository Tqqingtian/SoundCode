---@class ExampleGenConfig : System.Object
---@field public LuaCallCSharp System.Type[] @static
---@field public CSharpCallLua System.Type[] @static
---@field public BlackList string[][] @static
local m = {}

ExampleGenConfig = m
return m
