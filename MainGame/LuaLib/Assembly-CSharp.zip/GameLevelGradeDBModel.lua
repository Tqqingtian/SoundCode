---@class GameLevelGradeDBModel : TQ.DataTableDBModelBase_2_GameLevelGradeDBModel_GameLevelGradeEntity_
---@field public DataTableName string
local m = {}

GameLevelGradeDBModel = m
return m
