---@class Coroutine_Runner : UnityEngine.MonoBehaviour
local m = {}

Coroutine_Runner = m
return m
