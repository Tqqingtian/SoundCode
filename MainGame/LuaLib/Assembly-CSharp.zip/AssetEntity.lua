---@class AssetEntity : System.Object
---@field public Category AssetCategory
---@field public AssetName string
---@field public AssetFullName string
---@field public AssetBundleName string
---@field public DependsAssetList AssetDependsEntity[]
local m = {}

AssetEntity = m
return m
