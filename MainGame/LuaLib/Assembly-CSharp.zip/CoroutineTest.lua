---@class CoroutineTest : UnityEngine.MonoBehaviour
local m = {}

CoroutineTest = m
return m
