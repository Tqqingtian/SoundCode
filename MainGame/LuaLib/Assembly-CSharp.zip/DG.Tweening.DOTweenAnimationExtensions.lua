---@class DG.Tweening.DOTweenAnimationExtensions : System.Object
local m = {}

---@static
---@param t System.Type
---@param tBase System.Type
---@return boolean
function m.IsSameOrSubclassOf(t, tBase) end

DG.Tweening.DOTweenAnimationExtensions = m
return m
