---@class TQ.TQComponent : UnityEngine.MonoBehaviour
---@field public InstanceId number
local m = {}

TQ.TQComponent = m
return m
