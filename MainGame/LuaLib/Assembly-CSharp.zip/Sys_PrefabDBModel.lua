---@class Sys_PrefabDBModel : TQ.DataTableDBModelBase_2_Sys_PrefabDBModel_Sys_PrefabEntity_
---@field public DataTableName string
local m = {}

Sys_PrefabDBModel = m
return m
