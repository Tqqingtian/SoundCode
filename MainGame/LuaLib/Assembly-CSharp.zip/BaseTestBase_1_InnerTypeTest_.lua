---@class BaseTestBase_1_InnerTypeTest_ : BaseTestHelper
local m = {}

---@virtual
---@param p number
function m:Foo(p) end

BaseTestBase_1_InnerTypeTest_ = m
return m
