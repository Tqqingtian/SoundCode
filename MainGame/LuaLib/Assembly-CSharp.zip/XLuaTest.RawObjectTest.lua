---@class XLuaTest.RawObjectTest : UnityEngine.MonoBehaviour
local m = {}

---@static
---@param o any
function m.PrintType(o) end

XLuaTest.RawObjectTest = m
return m
