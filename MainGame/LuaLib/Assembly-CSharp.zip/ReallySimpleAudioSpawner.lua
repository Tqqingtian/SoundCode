---@class ReallySimpleAudioSpawner : UnityEngine.MonoBehaviour
---@field public prefab UnityEngine.AudioSource
---@field public musicPrefab UnityEngine.AudioSource
---@field public spawnInterval number
local m = {}

ReallySimpleAudioSpawner = m
return m
