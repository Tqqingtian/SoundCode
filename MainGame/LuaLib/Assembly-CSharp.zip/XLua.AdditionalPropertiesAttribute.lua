---@class XLua.AdditionalPropertiesAttribute : System.Attribute
local m = {}

XLua.AdditionalPropertiesAttribute = m
return m
