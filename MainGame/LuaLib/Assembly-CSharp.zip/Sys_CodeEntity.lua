---@class Sys_CodeEntity : TQ.DataTableEntityBase
---@field public Desc string
---@field public Key string
local m = {}

Sys_CodeEntity = m
return m
