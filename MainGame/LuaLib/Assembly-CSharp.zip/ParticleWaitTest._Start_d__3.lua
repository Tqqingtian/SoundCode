---@class ParticleWaitTest._Start_d__3 : System.Object
---@field public <>4__this ParticleWaitTest
local m = {}

ParticleWaitTest._Start_d__3 = m
return m
