---@class Sys_SoundEntity : TQ.DataTableEntityBase
---@field public Desc string
---@field public AssetPath string
---@field public Is3D number
---@field public Volume number
local m = {}

Sys_SoundEntity = m
return m
