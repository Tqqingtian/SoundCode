---@class MessageBox.__c__DisplayClass1_0 : System.Object
---@field public confirmBtn UnityEngine.UI.Button
---@field public cancelBtn UnityEngine.UI.Button
---@field public confirmPanel UnityEngine.Transform
---@field public onFinished fun(obj:boolean)
---@field public cleanup fun()
local m = {}

MessageBox.__c__DisplayClass1_0 = m
return m
