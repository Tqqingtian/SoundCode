---@class TQ.SocketManager : TQ.ManagerBase
local m = {}

---@virtual
function m:Dispose() end

TQ.SocketManager = m
return m
