---@class TQ.Variable_1_System_Int32_ : TQ.VariableBase
---@field public Value number
---@field public Type System.Type
local m = {}

TQ.Variable_1_System_Int32_ = m
return m
