---@class RoleOperation_LogOnGameServerReturnHandler : System.Object
local m = {}

---@static
---@param buffer string
function m.OnRoleOperation_LogOnGameServerReturn(buffer) end

RoleOperation_LogOnGameServerReturnHandler = m
return m
