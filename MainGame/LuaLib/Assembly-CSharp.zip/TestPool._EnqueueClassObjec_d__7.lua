---@class TestPool._EnqueueClassObjec_d__7 : System.Object
---@field public obj any
---@field public <>4__this TestPool
local m = {}

TestPool._EnqueueClassObjec_d__7 = m
return m
