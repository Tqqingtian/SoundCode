---@class VarString : UnityEngine.MonoBehaviour
local m = {}

VarString = m
return m
