---@class BaseTestBase_1_T_ : BaseTestHelper
local m = {}

---@virtual
---@param p number
function m:Foo(p) end

BaseTestBase_1_T_ = m
return m
