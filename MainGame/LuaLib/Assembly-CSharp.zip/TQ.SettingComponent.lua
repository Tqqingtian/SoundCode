---@class TQ.SettingComponent : TQ.TQBaseComponent
local m = {}

---@virtual
function m:Shutdown() end

TQ.SettingComponent = m
return m
