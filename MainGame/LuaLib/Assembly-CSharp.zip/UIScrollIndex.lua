---@class UIScrollIndex : UnityEngine.MonoBehaviour
---@field public _textIndex UnityEngine.UI.Text
---@field public _textOld UnityEngine.UI.Text
---@field public _buttonAdd UnityEngine.UI.Button
---@field public _buttonDel UnityEngine.UI.Button
---@field public Index number
---@field public Scroller UIScroller
local m = {}

UIScrollIndex = m
return m
