---@class TQ.SettingManager : TQ.ManagerBase
local m = {}

TQ.SettingManager = m
return m
