---@class XLua.HotfixAttribute : System.Attribute
---@field public Flag XLua.HotfixFlag
local m = {}

XLua.HotfixAttribute = m
return m
