---@class InnerTypeTest._InnerStruct : System.ValueType
---@field public x number
---@field public y number
local m = {}

InnerTypeTest._InnerStruct = m
return m
