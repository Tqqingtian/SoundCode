---@class MessageBox.__c__DisplayClass0_0 : System.Object
---@field public onFinished fun()
---@field public button UnityEngine.UI.Button
---@field public alertPanel UnityEngine.Transform
local m = {}

MessageBox.__c__DisplayClass0_0 = m
return m
