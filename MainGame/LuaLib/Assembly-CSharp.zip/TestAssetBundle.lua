---@class TestAssetBundle : UnityEngine.MonoBehaviour
local m = {}

TestAssetBundle = m
return m
