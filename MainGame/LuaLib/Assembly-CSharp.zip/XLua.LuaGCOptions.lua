---@class XLua.LuaGCOptions : System.Enum
---@field public LUA_GCSTOP XLua.LuaGCOptions @static
---@field public LUA_GCRESTART XLua.LuaGCOptions @static
---@field public LUA_GCCOLLECT XLua.LuaGCOptions @static
---@field public LUA_GCCOUNT XLua.LuaGCOptions @static
---@field public LUA_GCCOUNTB XLua.LuaGCOptions @static
---@field public LUA_GCSTEP XLua.LuaGCOptions @static
---@field public LUA_GCSETPAUSE XLua.LuaGCOptions @static
---@field public LUA_GCSETSTEPMUL XLua.LuaGCOptions @static
---@field public value__ number
local m = {}

XLua.LuaGCOptions = m
return m
