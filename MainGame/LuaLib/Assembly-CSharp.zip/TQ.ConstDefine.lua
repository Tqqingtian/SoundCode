---@class TQ.ConstDefine : System.Object
---@field public VersionFileName string @static
---@field public ResourceVersion string @static
---@field public AssetInfoName string @static
---@field public DataTableAssetBundlePath string @static
---@field public XLuaAssetBundlePath string @static
---@field public CusShadersAssetBundlePath string @static
local m = {}

TQ.ConstDefine = m
return m
