---@class Sys_EffectDBModel : TQ.DataTableDBModelBase_2_Sys_EffectDBModel_Sys_EffectEntity_
---@field public DataTableName string
local m = {}

Sys_EffectDBModel = m
return m
