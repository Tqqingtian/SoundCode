---@class XLua.SysGenConfig : System.Object
local m = {}

XLua.SysGenConfig = m
return m
