---@class XLua.Cast.Float : XLua.Cast.Any_1_System_Single_
local m = {}

XLua.Cast.Float = m
return m
