---@class GenericMethodExample : UnityEngine.MonoBehaviour
local m = {}

GenericMethodExample = m
return m
