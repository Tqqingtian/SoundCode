---@class Tutorial.DerivedClass.TestEnumInner : System.Enum
---@field public E3 Tutorial.DerivedClass.TestEnumInner @static
---@field public E4 Tutorial.DerivedClass.TestEnumInner @static
---@field public value__ number
local m = {}

Tutorial.DerivedClass.TestEnumInner = m
return m
