---@class Sys_SceneDBModel : TQ.DataTableDBModelBase_2_Sys_SceneDBModel_Sys_SceneEntity_
---@field public DataTableName string
local m = {}

Sys_SceneDBModel = m
return m
