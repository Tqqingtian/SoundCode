---@class MessageDBModel : TQ.DataTableDBModelBase_2_MessageDBModel_MessageEntity_
---@field public DataTableName string
local m = {}

MessageDBModel = m
return m
