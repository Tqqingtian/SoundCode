---@class ParticleWaitTest : UnityEngine.MonoBehaviour
---@field public spawnInterval number
---@field public particlesPoolName string
---@field public particleSystemPrefab UnityEngine.ParticleSystem
local m = {}

ParticleWaitTest = m
return m
