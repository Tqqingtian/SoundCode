---@class ByFile : UnityEngine.MonoBehaviour
local m = {}

ByFile = m
return m
