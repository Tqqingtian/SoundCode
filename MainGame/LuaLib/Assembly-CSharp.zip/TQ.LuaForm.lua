---@class TQ.LuaForm : TQ.UIFormBase
---@field public LuaComs TQ.LuaCom[]
local m = {}

---@param index number
---@return any
function m:GetLuaComs(index) end

TQ.LuaForm = m
return m
