---@class Sys_EffectEntity : TQ.DataTableEntityBase
---@field public Desc string
---@field public PrefabId number
---@field public KeepTime number
---@field public SoundId number
---@field public Type number
local m = {}

Sys_EffectEntity = m
return m
