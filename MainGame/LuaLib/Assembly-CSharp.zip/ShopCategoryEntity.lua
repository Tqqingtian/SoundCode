---@class ShopCategoryEntity : TQ.DataTableEntityBase
---@field public Name string
local m = {}

ShopCategoryEntity = m
return m
