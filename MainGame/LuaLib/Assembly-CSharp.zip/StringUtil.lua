---@class StringUtil : System.Object
local m = {}

---@static
---@param str string
---@return number
function m.ToInt(str) end

---@static
---@param str string
---@return number
function m.ToLong(str) end

---@static
---@param str string
---@return number
function m.ToFloat(str) end

StringUtil = m
return m
