---@class TQ.CacheDataManager : System.Object
local m = {}

function m:Clear() end

---@virtual
function m:Dispose() end

TQ.CacheDataManager = m
return m
