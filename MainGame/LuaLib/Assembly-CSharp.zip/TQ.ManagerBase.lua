---@class TQ.ManagerBase : System.Object
local m = {}

TQ.ManagerBase = m
return m
