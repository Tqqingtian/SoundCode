---@class MessageEntity : TQ.DataTableEntityBase
---@field public Msg string
---@field public Module string
---@field public Description string
local m = {}

MessageEntity = m
return m
