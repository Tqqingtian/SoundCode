---@class ChapterEntity : TQ.DataTableEntityBase
---@field public ChapterName string
---@field public GameLevelCount number
---@field public BG_Pic string
---@field public Uvx number
---@field public Uvy number
local m = {}

ChapterEntity = m
return m
