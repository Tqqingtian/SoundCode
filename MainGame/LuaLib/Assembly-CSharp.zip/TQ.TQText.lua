---@class TQ.TQText : UnityEngine.UI.Text
local m = {}

TQ.TQText = m
return m
