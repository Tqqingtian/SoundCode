---@class TestTime.__c : System.Object
---@field public <>9 TestTime.__c @static
---@field public <>9__2_0 fun() @static
---@field public <>9__2_1 fun(obj:number) @static
---@field public <>9__2_2 fun() @static
local m = {}

TestTime.__c = m
return m
