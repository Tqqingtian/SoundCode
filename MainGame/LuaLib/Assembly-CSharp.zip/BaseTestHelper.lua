---@class BaseTestHelper : System.Object
local m = {}

BaseTestHelper = m
return m
