---@class XLua.ReflectionUseAttribute : System.Attribute
local m = {}

XLua.ReflectionUseAttribute = m
return m
