---@class ShopDBModel : TQ.DataTableDBModelBase_2_ShopDBModel_ShopEntity_
---@field public DataTableName string
local m = {}

ShopDBModel = m
return m
