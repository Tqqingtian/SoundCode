---@class EquipDBModel : TQ.DataTableDBModelBase_2_EquipDBModel_EquipEntity_
---@field public DataTableName string
local m = {}

EquipDBModel = m
return m
