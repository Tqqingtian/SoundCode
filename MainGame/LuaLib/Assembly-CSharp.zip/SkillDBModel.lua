---@class SkillDBModel : TQ.DataTableDBModelBase_2_SkillDBModel_SkillEntity_
---@field public DataTableName string
local m = {}

SkillDBModel = m
return m
