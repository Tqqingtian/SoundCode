---@class Helloworld : UnityEngine.MonoBehaviour
local m = {}

Helloworld = m
return m
