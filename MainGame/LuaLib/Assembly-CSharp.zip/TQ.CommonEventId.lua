---@class TQ.CommonEventId : System.Object
---@field public RegComplete number @static
---@field public LogOnComplete number @static
local m = {}

TQ.CommonEventId = m
return m
