---@class SimpleSpawner._ParticleSpawner_d__7 : System.Object
---@field public <>4__this SimpleSpawner
local m = {}

SimpleSpawner._ParticleSpawner_d__7 = m
return m
