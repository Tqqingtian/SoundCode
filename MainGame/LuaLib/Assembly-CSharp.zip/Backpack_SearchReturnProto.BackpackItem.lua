---@class Backpack_SearchReturnProto.BackpackItem : System.ValueType
---@field public BackpackItemId number
---@field public GoodsType number
---@field public GoodsId number
---@field public GoodsServerId number
---@field public GoodsOverlayCount number
local m = {}

Backpack_SearchReturnProto.BackpackItem = m
return m
