---@class SignatureLoaderTest : UnityEngine.MonoBehaviour
---@field public PUBLIC_KEY string @static
local m = {}

SignatureLoaderTest = m
return m
