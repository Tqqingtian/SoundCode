---@class TQ.LocalizationDBModel : TQ.DataTableDBModelBase_2_TQ_LocalizationDBModel_TQ_DataTableEntityBase_
---@field public LocalizationDic System.Collections.Generic.Dictionary_2_System_String_System_String_
---@field public DataTableName string
local m = {}

TQ.LocalizationDBModel = m
return m
