---@class OnCreatedDelegateExample : UnityEngine.MonoBehaviour
---@field public poolName string
local m = {}

---@param pool PathologicalGames.SpawnPool
function m:RunMe(pool) end

OnCreatedDelegateExample = m
return m
