---@class TQ.UILayer : System.Object
local m = {}

TQ.UILayer = m
return m
