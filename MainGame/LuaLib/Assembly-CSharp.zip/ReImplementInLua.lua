---@class ReImplementInLua : UnityEngine.MonoBehaviour
local m = {}

ReImplementInLua = m
return m
