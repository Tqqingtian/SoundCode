---@class TQ.StreamingAssetsManager : System.Object
local m = {}

---@param fileUrl string
---@param onComplete fun(obj:string)
function m:ReadAssetBundle(fileUrl, onComplete) end

TQ.StreamingAssetsManager = m
return m
