---@class OnSpawnedExample : UnityEngine.MonoBehaviour
local m = {}

OnSpawnedExample = m
return m
