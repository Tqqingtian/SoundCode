---@class TQ.Variable_1_UnityEngine_GameObject_ : TQ.VariableBase
---@field public Value UnityEngine.GameObject
---@field public Type System.Type
local m = {}

TQ.Variable_1_UnityEngine_GameObject_ = m
return m
