---@class SpriteDBModel : TQ.DataTableDBModelBase_2_SpriteDBModel_SpriteEntity_
---@field public DataTableName string
local m = {}

SpriteDBModel = m
return m
