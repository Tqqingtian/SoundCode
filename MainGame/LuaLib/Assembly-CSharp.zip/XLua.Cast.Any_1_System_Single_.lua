---@class XLua.Cast.Any_1_System_Single_ : System.Object
---@field public Target any
local m = {}

XLua.Cast.Any_1_System_Single_ = m
return m
