---@class System_GameServerConfigReturnHandler : System.Object
local m = {}

---@static
---@param buffer string
function m.OnSystem_GameServerConfigReturn(buffer) end

System_GameServerConfigReturnHandler = m
return m
