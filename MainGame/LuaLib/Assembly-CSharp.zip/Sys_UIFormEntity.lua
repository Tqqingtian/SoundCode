---@class Sys_UIFormEntity : TQ.DataTableEntityBase
---@field public Desc string
---@field public Name string
---@field public UIGroupId number
---@field public DisableUILayer number
---@field public IsLock number
---@field public AssetPath_Chinese string
---@field public AssetPath_English string
local m = {}

Sys_UIFormEntity = m
return m
