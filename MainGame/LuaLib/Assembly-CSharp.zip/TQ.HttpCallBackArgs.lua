---@class TQ.HttpCallBackArgs : System.EventArgs
---@field public HasError boolean
---@field public Value string
---@field public Data string
local m = {}

TQ.HttpCallBackArgs = m
return m
