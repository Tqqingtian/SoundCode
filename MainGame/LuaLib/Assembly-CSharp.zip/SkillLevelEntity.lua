---@class SkillLevelEntity : TQ.DataTableEntityBase
---@field public SkillId number
---@field public Level number
---@field public HurtValueRate number
---@field public SpendMP number
---@field public StateTime number
---@field public AbnormalRatio number
---@field public AStateTimes number
---@field public AStatexiaohao number
---@field public SkillCDTime number
---@field public BuffChance number
---@field public BuffDuration number
---@field public BuffValue number
---@field public NeedCharacterLevel number
---@field public SpendGold number
local m = {}

SkillLevelEntity = m
return m
