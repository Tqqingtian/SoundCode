---@class TQ.GameObjManager : TQ.ManagerBase
local m = {}

TQ.GameObjManager = m
return m
