---@class CSCallLua : UnityEngine.MonoBehaviour
local m = {}

CSCallLua = m
return m
