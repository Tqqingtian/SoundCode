---@class UIFormId : System.Object
---@field public Loading number @static
---@field public UI_Task number @static
local m = {}

UIFormId = m
return m
