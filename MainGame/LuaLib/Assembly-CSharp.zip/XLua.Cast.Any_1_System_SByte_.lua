---@class XLua.Cast.Any_1_System_SByte_ : System.Object
---@field public Target any
local m = {}

XLua.Cast.Any_1_System_SByte_ = m
return m
