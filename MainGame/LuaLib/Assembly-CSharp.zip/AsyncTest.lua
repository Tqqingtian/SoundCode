---@class AsyncTest : UnityEngine.MonoBehaviour
local m = {}

AsyncTest = m
return m
