---@class TQ.DataTableEntityBase : System.Object
---@field public Id number
local m = {}

TQ.DataTableEntityBase = m
return m
