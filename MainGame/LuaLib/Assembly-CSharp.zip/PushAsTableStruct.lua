---@class PushAsTableStruct : System.ValueType
---@field public x number
---@field public y number
local m = {}

PushAsTableStruct = m
return m
