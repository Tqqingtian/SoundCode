---@class Tutorial.Param1 : System.ValueType
---@field public x number
---@field public y string
local m = {}

Tutorial.Param1 = m
return m
