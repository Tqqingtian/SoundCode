---@class Backpack_GoodsChangeReturnHandler : System.Object
local m = {}

---@static
---@param buffer string
function m.OnBackpack_GoodsChangeReturn(buffer) end

Backpack_GoodsChangeReturnHandler = m
return m
