---@class Foo2Child : Foo2Parent
local m = {}

Foo2Child = m
return m
