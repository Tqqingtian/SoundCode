---@class TQ.LuaCom : System.Object
---@field public Name string
---@field public Type TQ.LuaConType
---@field public Trans UnityEngine.Transform
local m = {}

TQ.LuaCom = m
return m
