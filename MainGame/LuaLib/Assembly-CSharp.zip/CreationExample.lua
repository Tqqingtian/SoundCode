---@class CreationExample : UnityEngine.MonoBehaviour
---@field public testPrefab UnityEngine.Transform
---@field public poolName string
---@field public spawnAmount number
---@field public spawnInterval number
local m = {}

CreationExample = m
return m
