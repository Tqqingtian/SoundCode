---@class ShopEntity : TQ.DataTableEntityBase
---@field public ShopCategoryId number
---@field public GoodsType number
---@field public GoodsId number
---@field public OldPrice number
---@field public Price number
---@field public SellStatus number
local m = {}

ShopEntity = m
return m
