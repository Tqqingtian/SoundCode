---@class CustomLoader.__c : System.Object
---@field public <>9 CustomLoader.__c @static
---@field public <>9__1_0 fun(filepath:System.String):(, System.String) @static
local m = {}

CustomLoader.__c = m
return m
