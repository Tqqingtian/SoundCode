---@class ReallySimpleAudioSpawner._MusicSpawner_d__5 : System.Object
---@field public <>4__this ReallySimpleAudioSpawner
local m = {}

ReallySimpleAudioSpawner._MusicSpawner_d__5 = m
return m
