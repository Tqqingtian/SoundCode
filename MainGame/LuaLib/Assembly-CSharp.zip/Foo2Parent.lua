---@class Foo2Parent : System.Object
local m = {}

Foo2Parent = m
return m
