---@class UITaskForm : TQ.UIFormBase
local m = {}

UITaskForm = m
return m
