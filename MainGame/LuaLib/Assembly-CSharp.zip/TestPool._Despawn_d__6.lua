---@class TestPool._Despawn_d__6 : System.Object
---@field public poolId number
---@field public instance UnityEngine.Transform
---@field public <>4__this TestPool
local m = {}

TestPool._Despawn_d__6 = m
return m
