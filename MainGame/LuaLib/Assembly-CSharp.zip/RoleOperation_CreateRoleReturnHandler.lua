---@class RoleOperation_CreateRoleReturnHandler : System.Object
local m = {}

---@static
---@param buffer string
function m.OnRoleOperation_CreateRoleReturn(buffer) end

RoleOperation_CreateRoleReturnHandler = m
return m
