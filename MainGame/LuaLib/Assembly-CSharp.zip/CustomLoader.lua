---@class CustomLoader : UnityEngine.MonoBehaviour
local m = {}

CustomLoader = m
return m
