---@class TQ.LuaConType : System.Enum
---@field public GameObject TQ.LuaConType @static
---@field public Transform TQ.LuaConType @static
---@field public Button TQ.LuaConType @static
---@field public Image TQ.LuaConType @static
---@field public TQImage TQ.LuaConType @static
---@field public Text TQ.LuaConType @static
---@field public TQText TQ.LuaConType @static
---@field public RawImage TQ.LuaConType @static
---@field public InputField TQ.LuaConType @static
---@field public Scrollbar TQ.LuaConType @static
---@field public ScrollRect TQ.LuaConType @static
---@field public MulityScroll TQ.LuaConType @static
---@field public value__ number
local m = {}

TQ.LuaConType = m
return m
