---@class ByString : UnityEngine.MonoBehaviour
local m = {}

ByString = m
return m
