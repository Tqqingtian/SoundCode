---@class TQ.GameObjComponent : TQ.TQBaseComponent
local m = {}

---@virtual
function m:Shutdown() end

TQ.GameObjComponent = m
return m
