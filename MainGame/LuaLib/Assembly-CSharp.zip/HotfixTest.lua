---@class HotfixTest : UnityEngine.MonoBehaviour
local m = {}

HotfixTest = m
return m
