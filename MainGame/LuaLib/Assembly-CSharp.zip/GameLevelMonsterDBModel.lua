---@class GameLevelMonsterDBModel : TQ.DataTableDBModelBase_2_GameLevelMonsterDBModel_GameLevelMonsterEntity_
---@field public DataTableName string
local m = {}

GameLevelMonsterDBModel = m
return m
