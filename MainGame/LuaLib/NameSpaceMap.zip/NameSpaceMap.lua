CS = {
	System = System;
	TQ = TQ;
	Tutorial = Tutorial;
	UnityEngine = UnityEngine;
	XLuaTest = XLuaTest;

	BaseTest = BaseTest;
	Foo = Foo;
	Foo1Child = Foo1Child;
	Foo1Parent = Foo1Parent;
	Foo2Child = Foo2Child;
	Foo2Parent = Foo2Parent;
	FooExtension = FooExtension;
	GameUtil = GameUtil;
	LuaBehaviour = LuaBehaviour;
}