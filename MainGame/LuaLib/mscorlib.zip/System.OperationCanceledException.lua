---@class System.OperationCanceledException : System.SystemException
---@field public CancellationToken System.Threading.CancellationToken
local m = {}

System.OperationCanceledException = m
return m
