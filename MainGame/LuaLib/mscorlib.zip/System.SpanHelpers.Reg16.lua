---@class System.SpanHelpers.Reg16 : System.ValueType
local m = {}

System.SpanHelpers.Reg16 = m
return m
