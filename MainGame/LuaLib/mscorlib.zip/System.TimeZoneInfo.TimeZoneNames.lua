---@class System.TimeZoneInfo.TimeZoneNames : System.Enum
---@field public StandardNameIdx System.TimeZoneInfo.TimeZoneNames @static
---@field public DaylightNameIdx System.TimeZoneInfo.TimeZoneNames @static
---@field public value__ number
local m = {}

System.TimeZoneInfo.TimeZoneNames = m
return m
