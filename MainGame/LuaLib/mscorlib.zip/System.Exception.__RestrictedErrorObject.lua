---@class System.Exception.__RestrictedErrorObject : System.Object
---@field public RealErrorObject any
local m = {}

System.Exception.__RestrictedErrorObject = m
return m
