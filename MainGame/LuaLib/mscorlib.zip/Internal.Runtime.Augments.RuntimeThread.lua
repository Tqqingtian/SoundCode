---@class Internal.Runtime.Augments.RuntimeThread : System.Object
local m = {}

---@static
function m.InitializeThreadPoolThread() end

Internal.Runtime.Augments.RuntimeThread = m
return m
