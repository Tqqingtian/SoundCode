---@class System.__Filters : System.Object
local m = {}

System.__Filters = m
return m
