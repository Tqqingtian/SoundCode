---@class System.CLRConfig : System.Object
local m = {}

System.CLRConfig = m
return m
