---@class System.AppContext.SwitchValueState : System.Enum
---@field public HasFalseValue System.AppContext.SwitchValueState @static
---@field public HasTrueValue System.AppContext.SwitchValueState @static
---@field public HasLookedForOverride System.AppContext.SwitchValueState @static
---@field public UnknownValue System.AppContext.SwitchValueState @static
---@field public value__ number
local m = {}

System.AppContext.SwitchValueState = m
return m
