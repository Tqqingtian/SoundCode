---@class Interop : System.Object
local m = {}

Interop = m
return m
