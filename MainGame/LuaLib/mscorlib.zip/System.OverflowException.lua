---@class System.OverflowException : System.ArithmeticException
local m = {}

System.OverflowException = m
return m
