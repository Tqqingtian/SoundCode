---@class System.Array.FunctorComparer_1_T_ : System.Object
local m = {}

---@virtual
---@param x any
---@param y any
---@return number
function m:Compare(x, y) end

System.Array.FunctorComparer_1_T_ = m
return m
