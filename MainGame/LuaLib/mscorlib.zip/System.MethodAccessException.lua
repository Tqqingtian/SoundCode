---@class System.MethodAccessException : System.MemberAccessException
local m = {}

System.MethodAccessException = m
return m
