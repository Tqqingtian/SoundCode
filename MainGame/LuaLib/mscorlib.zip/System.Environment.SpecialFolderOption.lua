---@class System.Environment.SpecialFolderOption : System.Enum
---@field public None System.Environment.SpecialFolderOption @static
---@field public DoNotVerify System.Environment.SpecialFolderOption @static
---@field public Create System.Environment.SpecialFolderOption @static
---@field public value__ number
local m = {}

System.Environment.SpecialFolderOption = m
return m
