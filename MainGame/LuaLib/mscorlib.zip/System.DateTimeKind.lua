---@class System.DateTimeKind : System.Enum
---@field public Unspecified System.DateTimeKind @static
---@field public Utc System.DateTimeKind @static
---@field public Local System.DateTimeKind @static
---@field public value__ number
local m = {}

System.DateTimeKind = m
return m
