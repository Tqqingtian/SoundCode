---@class System.TimeZoneInfo.__c : System.Object
---@field public <>9 System.TimeZoneInfo.__c @static
---@field public <>9__19_0 fun(x:System.TimeZoneInfo.AdjustmentRule, y:System.TimeZoneInfo.AdjustmentRule): @static
local m = {}

System.TimeZoneInfo.__c = m
return m
