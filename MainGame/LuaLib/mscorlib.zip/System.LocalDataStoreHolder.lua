---@class System.LocalDataStoreHolder : System.Object
---@field public Store System.LocalDataStore
local m = {}

System.LocalDataStoreHolder = m
return m
