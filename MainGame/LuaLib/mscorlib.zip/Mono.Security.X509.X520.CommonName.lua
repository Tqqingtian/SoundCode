---@class Mono.Security.X509.X520.CommonName : Mono.Security.X509.X520.AttributeTypeAndValue
local m = {}

Mono.Security.X509.X520.CommonName = m
return m
