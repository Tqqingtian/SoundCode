---@class Mono.Globalization.Unicode.Level2Map : System.Object
---@field public Source number
---@field public Replace number
local m = {}

Mono.Globalization.Unicode.Level2Map = m
return m
