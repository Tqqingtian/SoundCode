---@class System.TypeNameParser : System.Object
local m = {}

System.TypeNameParser = m
return m
