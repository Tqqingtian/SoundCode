---@class System.MonoTypeInfo : System.Object
---@field public full_name string
---@field public default_ctor System.Reflection.MonoCMethod
local m = {}

System.MonoTypeInfo = m
return m
