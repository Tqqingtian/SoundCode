---@class System.ActivationContext.ContextForm : System.Enum
---@field public Loose System.ActivationContext.ContextForm @static
---@field public StoreBounded System.ActivationContext.ContextForm @static
---@field public value__ number
local m = {}

System.ActivationContext.ContextForm = m
return m
