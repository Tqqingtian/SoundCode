---@class Microsoft.Win32.SafeHandles.SafeRegistryHandle : Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
local m = {}

Microsoft.Win32.SafeHandles.SafeRegistryHandle = m
return m
