---@class System.DllNotFoundException : System.TypeLoadException
local m = {}

System.DllNotFoundException = m
return m
