---@class System.Enum.ValuesAndNames : System.Object
---@field public Values number[]
---@field public Names string[]
local m = {}

System.Enum.ValuesAndNames = m
return m
