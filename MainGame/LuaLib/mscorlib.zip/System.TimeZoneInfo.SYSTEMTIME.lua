---@class System.TimeZoneInfo.SYSTEMTIME : System.ValueType
local m = {}

System.TimeZoneInfo.SYSTEMTIME = m
return m
