---@class System.TimeZoneInfo.TimeZoneInfoComparer : System.Object
local m = {}

System.TimeZoneInfo.TimeZoneInfoComparer = m
return m
