---@class System.TimeZoneInfo.TIME_ZONE_INFORMATION : System.ValueType
local m = {}

System.TimeZoneInfo.TIME_ZONE_INFORMATION = m
return m
