---@class System.DateTimeRawInfo : System.ValueType
local m = {}

System.DateTimeRawInfo = m
return m
