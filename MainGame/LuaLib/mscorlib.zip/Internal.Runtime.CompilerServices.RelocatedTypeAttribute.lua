---@class Internal.Runtime.CompilerServices.RelocatedTypeAttribute : System.Attribute
local m = {}

Internal.Runtime.CompilerServices.RelocatedTypeAttribute = m
return m
