---@class Mono.SafeGPtrArrayHandle : System.ValueType
local m = {}

---@virtual
function m:Dispose() end

Mono.SafeGPtrArrayHandle = m
return m
