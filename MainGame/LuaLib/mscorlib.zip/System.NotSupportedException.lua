---@class System.NotSupportedException : System.SystemException
local m = {}

System.NotSupportedException = m
return m
