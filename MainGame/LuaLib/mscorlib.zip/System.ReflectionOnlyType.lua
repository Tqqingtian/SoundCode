---@class System.ReflectionOnlyType : System.RuntimeType
---@field public TypeHandle System.RuntimeTypeHandle
local m = {}

System.ReflectionOnlyType = m
return m
