---@class Mono.Security.X509.X520.OrganizationalUnitName : Mono.Security.X509.X520.AttributeTypeAndValue
local m = {}

Mono.Security.X509.X520.OrganizationalUnitName = m
return m
