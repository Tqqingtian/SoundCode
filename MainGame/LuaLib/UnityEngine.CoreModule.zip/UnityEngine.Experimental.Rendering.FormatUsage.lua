---@class UnityEngine.Experimental.Rendering.FormatUsage : System.Enum
---@field public Sample UnityEngine.Experimental.Rendering.FormatUsage @static
---@field public Linear UnityEngine.Experimental.Rendering.FormatUsage @static
---@field public Render UnityEngine.Experimental.Rendering.FormatUsage @static
---@field public Blend UnityEngine.Experimental.Rendering.FormatUsage @static
---@field public LoadStore UnityEngine.Experimental.Rendering.FormatUsage @static
---@field public MSAA2x UnityEngine.Experimental.Rendering.FormatUsage @static
---@field public MSAA4x UnityEngine.Experimental.Rendering.FormatUsage @static
---@field public MSAA8x UnityEngine.Experimental.Rendering.FormatUsage @static
---@field public value__ number
local m = {}

UnityEngine.Experimental.Rendering.FormatUsage = m
return m
