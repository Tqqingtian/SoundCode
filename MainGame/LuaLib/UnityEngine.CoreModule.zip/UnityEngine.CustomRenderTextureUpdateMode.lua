---@class UnityEngine.CustomRenderTextureUpdateMode : System.Enum
---@field public OnLoad UnityEngine.CustomRenderTextureUpdateMode @static
---@field public Realtime UnityEngine.CustomRenderTextureUpdateMode @static
---@field public OnDemand UnityEngine.CustomRenderTextureUpdateMode @static
---@field public value__ number
local m = {}

UnityEngine.CustomRenderTextureUpdateMode = m
return m
