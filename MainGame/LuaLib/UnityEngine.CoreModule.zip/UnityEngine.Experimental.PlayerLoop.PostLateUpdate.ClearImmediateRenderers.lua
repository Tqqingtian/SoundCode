---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ClearImmediateRenderers : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ClearImmediateRenderers = m
return m
