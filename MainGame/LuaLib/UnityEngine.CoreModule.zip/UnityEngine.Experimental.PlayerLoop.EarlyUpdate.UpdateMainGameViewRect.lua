---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UpdateMainGameViewRect : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UpdateMainGameViewRect = m
return m
