---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ThreadedLoadingDebug : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ThreadedLoadingDebug = m
return m
