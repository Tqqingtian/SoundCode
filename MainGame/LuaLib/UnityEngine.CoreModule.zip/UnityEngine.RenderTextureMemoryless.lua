---@class UnityEngine.RenderTextureMemoryless : System.Enum
---@field public None UnityEngine.RenderTextureMemoryless @static
---@field public Color UnityEngine.RenderTextureMemoryless @static
---@field public Depth UnityEngine.RenderTextureMemoryless @static
---@field public MSAA UnityEngine.RenderTextureMemoryless @static
---@field public value__ number
local m = {}

UnityEngine.RenderTextureMemoryless = m
return m
