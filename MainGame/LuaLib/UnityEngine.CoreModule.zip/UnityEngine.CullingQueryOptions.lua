---@class UnityEngine.CullingQueryOptions : System.Enum
---@field public Normal UnityEngine.CullingQueryOptions @static
---@field public IgnoreVisibility UnityEngine.CullingQueryOptions @static
---@field public IgnoreDistance UnityEngine.CullingQueryOptions @static
---@field public value__ number
local m = {}

UnityEngine.CullingQueryOptions = m
return m
