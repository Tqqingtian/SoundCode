---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateCustomRenderTextures : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateCustomRenderTextures = m
return m
