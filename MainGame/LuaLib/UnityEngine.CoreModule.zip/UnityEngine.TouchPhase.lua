---@class UnityEngine.TouchPhase : System.Enum
---@field public Began UnityEngine.TouchPhase @static
---@field public Moved UnityEngine.TouchPhase @static
---@field public Stationary UnityEngine.TouchPhase @static
---@field public Ended UnityEngine.TouchPhase @static
---@field public Canceled UnityEngine.TouchPhase @static
---@field public value__ number
local m = {}

UnityEngine.TouchPhase = m
return m
