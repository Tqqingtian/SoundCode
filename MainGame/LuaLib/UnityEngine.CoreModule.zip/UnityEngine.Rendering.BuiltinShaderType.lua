---@class UnityEngine.Rendering.BuiltinShaderType : System.Enum
---@field public DeferredShading UnityEngine.Rendering.BuiltinShaderType @static
---@field public DeferredReflections UnityEngine.Rendering.BuiltinShaderType @static
---@field public LegacyDeferredLighting UnityEngine.Rendering.BuiltinShaderType @static
---@field public ScreenSpaceShadows UnityEngine.Rendering.BuiltinShaderType @static
---@field public DepthNormals UnityEngine.Rendering.BuiltinShaderType @static
---@field public MotionVectors UnityEngine.Rendering.BuiltinShaderType @static
---@field public LightHalo UnityEngine.Rendering.BuiltinShaderType @static
---@field public LensFlare UnityEngine.Rendering.BuiltinShaderType @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.BuiltinShaderType = m
return m
