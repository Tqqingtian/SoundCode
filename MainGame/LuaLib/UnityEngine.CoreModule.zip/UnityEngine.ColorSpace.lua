---@class UnityEngine.ColorSpace : System.Enum
---@field public Uninitialized UnityEngine.ColorSpace @static
---@field public Gamma UnityEngine.ColorSpace @static
---@field public Linear UnityEngine.ColorSpace @static
---@field public value__ number
local m = {}

UnityEngine.ColorSpace = m
return m
