---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.SpriteAtlasManagerUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.SpriteAtlasManagerUpdate = m
return m
