---@class UnityEngine.Rendering.LightShadowResolution : System.Enum
---@field public FromQualitySettings UnityEngine.Rendering.LightShadowResolution @static
---@field public Low UnityEngine.Rendering.LightShadowResolution @static
---@field public Medium UnityEngine.Rendering.LightShadowResolution @static
---@field public High UnityEngine.Rendering.LightShadowResolution @static
---@field public VeryHigh UnityEngine.Rendering.LightShadowResolution @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.LightShadowResolution = m
return m
