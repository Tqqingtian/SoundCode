---@class UnityEngine.Rendering.CameraHDRMode : System.Enum
---@field public FP16 UnityEngine.Rendering.CameraHDRMode @static
---@field public R11G11B10 UnityEngine.Rendering.CameraHDRMode @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.CameraHDRMode = m
return m
