---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.DirectorSampleTime : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.DirectorSampleTime = m
return m
