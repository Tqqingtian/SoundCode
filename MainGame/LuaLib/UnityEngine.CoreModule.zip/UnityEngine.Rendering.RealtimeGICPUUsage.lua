---@class UnityEngine.Rendering.RealtimeGICPUUsage : System.Enum
---@field public Low UnityEngine.Rendering.RealtimeGICPUUsage @static
---@field public Medium UnityEngine.Rendering.RealtimeGICPUUsage @static
---@field public High UnityEngine.Rendering.RealtimeGICPUUsage @static
---@field public Unlimited UnityEngine.Rendering.RealtimeGICPUUsage @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.RealtimeGICPUUsage = m
return m
