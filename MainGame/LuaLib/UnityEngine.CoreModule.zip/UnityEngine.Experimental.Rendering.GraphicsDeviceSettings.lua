---@class UnityEngine.Experimental.Rendering.GraphicsDeviceSettings : System.Object
---@field public waitForPresentSyncPoint UnityEngine.Experimental.Rendering.WaitForPresentSyncPoint @static
---@field public graphicsJobsSyncPoint UnityEngine.Experimental.Rendering.GraphicsJobsSyncPoint @static
local m = {}

UnityEngine.Experimental.Rendering.GraphicsDeviceSettings = m
return m
