---@class UnityEngine.Experimental.PlayerLoop.Initialization.PlayerUpdateTime : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.Initialization.PlayerUpdateTime = m
return m
