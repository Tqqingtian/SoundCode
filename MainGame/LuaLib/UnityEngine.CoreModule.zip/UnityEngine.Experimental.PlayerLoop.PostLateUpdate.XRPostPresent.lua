---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.XRPostPresent : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.XRPostPresent = m
return m
