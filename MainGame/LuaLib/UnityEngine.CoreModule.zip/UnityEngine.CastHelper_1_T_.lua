---@class UnityEngine.CastHelper_1_T_ : System.ValueType
---@field public t any
---@field public onePointerFurtherThanT System.IntPtr
local m = {}

UnityEngine.CastHelper_1_T_ = m
return m
