---@class UnityEngine.Experimental.PlayerLoop.PreUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreUpdate = m
return m
