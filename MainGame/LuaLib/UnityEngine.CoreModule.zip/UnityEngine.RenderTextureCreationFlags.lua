---@class UnityEngine.RenderTextureCreationFlags : System.Enum
---@field public MipMap UnityEngine.RenderTextureCreationFlags @static
---@field public AutoGenerateMips UnityEngine.RenderTextureCreationFlags @static
---@field public SRGB UnityEngine.RenderTextureCreationFlags @static
---@field public EyeTexture UnityEngine.RenderTextureCreationFlags @static
---@field public EnableRandomWrite UnityEngine.RenderTextureCreationFlags @static
---@field public CreatedFromScript UnityEngine.RenderTextureCreationFlags @static
---@field public AllowVerticalFlip UnityEngine.RenderTextureCreationFlags @static
---@field public NoResolvedColorSurface UnityEngine.RenderTextureCreationFlags @static
---@field public DynamicallyScalable UnityEngine.RenderTextureCreationFlags @static
---@field public BindMS UnityEngine.RenderTextureCreationFlags @static
---@field public value__ number
local m = {}

UnityEngine.RenderTextureCreationFlags = m
return m
