---@class UnityEngine.Experimental.PlayerLoop.PreLateUpdate.EndGraphicsJobsAfterScriptUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreLateUpdate.EndGraphicsJobsAfterScriptUpdate = m
return m
