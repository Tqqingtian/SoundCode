---@class UnityEngine.Experimental.PlayerLoop.PreUpdate.SendMouseEvents : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreUpdate.SendMouseEvents = m
return m
