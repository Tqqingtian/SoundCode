---@class UnityEngine.LensFlare : UnityEngine.Behaviour
---@field public brightness number
---@field public fadeSpeed number
---@field public color UnityEngine.Color
---@field public flare UnityEngine.Flare
local m = {}

UnityEngine.LensFlare = m
return m
