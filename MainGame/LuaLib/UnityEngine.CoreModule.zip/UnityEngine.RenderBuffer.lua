---@class UnityEngine.RenderBuffer : System.ValueType
local m = {}

---@return System.IntPtr
function m:GetNativeRenderBufferPtr() end

UnityEngine.RenderBuffer = m
return m
