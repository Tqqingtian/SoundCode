---@class UnityEngine.Experimental.PlayerLoop.FixedUpdate.ScriptRunBehaviourFixedUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.FixedUpdate.ScriptRunBehaviourFixedUpdate = m
return m
