---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.PollPlayerConnection : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.PollPlayerConnection = m
return m
