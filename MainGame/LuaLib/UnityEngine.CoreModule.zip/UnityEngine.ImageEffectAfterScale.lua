---@class UnityEngine.ImageEffectAfterScale : System.Attribute
local m = {}

UnityEngine.ImageEffectAfterScale = m
return m
