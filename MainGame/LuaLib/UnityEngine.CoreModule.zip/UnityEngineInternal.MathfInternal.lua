---@class UnityEngineInternal.MathfInternal : System.ValueType
---@field public FloatMinNormal number @static
---@field public FloatMinDenormal number @static
---@field public IsFlushToZeroEnabled boolean @static
local m = {}

UnityEngineInternal.MathfInternal = m
return m
