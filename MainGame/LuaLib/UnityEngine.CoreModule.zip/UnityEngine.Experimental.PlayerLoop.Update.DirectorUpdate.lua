---@class UnityEngine.Experimental.PlayerLoop.Update.DirectorUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.Update.DirectorUpdate = m
return m
