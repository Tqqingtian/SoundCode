---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ProfilerSynchronizeStats : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ProfilerSynchronizeStats = m
return m
