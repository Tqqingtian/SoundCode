---@class UnityEngine.Rendering.CameraEventUtils : System.Object
local m = {}

---@static
---@param value UnityEngine.Rendering.CameraEvent
---@return boolean
function m.IsValid(value) end

UnityEngine.Rendering.CameraEventUtils = m
return m
