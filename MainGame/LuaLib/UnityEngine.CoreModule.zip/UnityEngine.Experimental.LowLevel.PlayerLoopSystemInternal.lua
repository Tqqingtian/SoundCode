---@class UnityEngine.Experimental.LowLevel.PlayerLoopSystemInternal : System.ValueType
---@field public type System.Type
---@field public updateDelegate fun()
---@field public updateFunction System.IntPtr
---@field public loopConditionFunction System.IntPtr
---@field public numSubSystems number
local m = {}

UnityEngine.Experimental.LowLevel.PlayerLoopSystemInternal = m
return m
