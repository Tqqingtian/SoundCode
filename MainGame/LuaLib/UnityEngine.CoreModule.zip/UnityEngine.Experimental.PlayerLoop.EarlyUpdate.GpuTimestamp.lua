---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.GpuTimestamp : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.GpuTimestamp = m
return m
