---@class UnityEngine.Experimental.PlayerLoop.PreLateUpdate.ConstraintManagerUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreLateUpdate.ConstraintManagerUpdate = m
return m
