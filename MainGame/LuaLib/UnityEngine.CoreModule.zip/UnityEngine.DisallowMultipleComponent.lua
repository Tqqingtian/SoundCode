---@class UnityEngine.DisallowMultipleComponent : System.Attribute
local m = {}

UnityEngine.DisallowMultipleComponent = m
return m
