---@class UnityEngine.OcclusionArea : UnityEngine.Component
---@field public center UnityEngine.Vector3
---@field public size UnityEngine.Vector3
local m = {}

UnityEngine.OcclusionArea = m
return m
