---@class Unity.Collections.LowLevel.Unsafe.EnforceJobResult : System.Enum
---@field public AllJobsAlreadySynced Unity.Collections.LowLevel.Unsafe.EnforceJobResult @static
---@field public DidSyncRunningJobs Unity.Collections.LowLevel.Unsafe.EnforceJobResult @static
---@field public HandleWasAlreadyDeallocated Unity.Collections.LowLevel.Unsafe.EnforceJobResult @static
---@field public value__ number
local m = {}

Unity.Collections.LowLevel.Unsafe.EnforceJobResult = m
return m
