---@class UnityEngine.Experimental.PlayerLoop.PreLateUpdate.DirectorUpdateAnimationBegin : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreLateUpdate.DirectorUpdateAnimationBegin = m
return m
