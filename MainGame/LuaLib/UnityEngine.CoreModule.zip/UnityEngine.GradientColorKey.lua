---@class UnityEngine.GradientColorKey : System.ValueType
---@field public color UnityEngine.Color
---@field public time number
local m = {}

UnityEngine.GradientColorKey = m
return m
