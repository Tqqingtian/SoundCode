---@class UnityEngine.Rendering.RenderBufferStoreAction : System.Enum
---@field public Store UnityEngine.Rendering.RenderBufferStoreAction @static
---@field public Resolve UnityEngine.Rendering.RenderBufferStoreAction @static
---@field public StoreAndResolve UnityEngine.Rendering.RenderBufferStoreAction @static
---@field public DontCare UnityEngine.Rendering.RenderBufferStoreAction @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.RenderBufferStoreAction = m
return m
