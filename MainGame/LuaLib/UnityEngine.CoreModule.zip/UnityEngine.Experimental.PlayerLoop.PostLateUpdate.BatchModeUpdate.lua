---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.BatchModeUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.BatchModeUpdate = m
return m
