---@class UnityEngine.Experimental.PlayerLoop.PreUpdate.NewInputUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreUpdate.NewInputUpdate = m
return m
