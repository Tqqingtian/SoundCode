---@class UnityEngine.PreloadData : UnityEngine.Object
local m = {}

UnityEngine.PreloadData = m
return m
