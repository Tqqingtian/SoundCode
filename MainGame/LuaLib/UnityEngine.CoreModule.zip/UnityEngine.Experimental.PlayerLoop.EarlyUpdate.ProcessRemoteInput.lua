---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.ProcessRemoteInput : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.ProcessRemoteInput = m
return m
