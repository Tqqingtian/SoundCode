---@class UnityEngine.Camera.GateFitMode : System.Enum
---@field public Vertical UnityEngine.Camera.GateFitMode @static
---@field public Horizontal UnityEngine.Camera.GateFitMode @static
---@field public Fill UnityEngine.Camera.GateFitMode @static
---@field public Overscan UnityEngine.Camera.GateFitMode @static
---@field public None UnityEngine.Camera.GateFitMode @static
---@field public value__ number
local m = {}

UnityEngine.Camera.GateFitMode = m
return m
