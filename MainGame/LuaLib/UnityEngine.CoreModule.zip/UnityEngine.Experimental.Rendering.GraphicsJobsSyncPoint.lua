---@class UnityEngine.Experimental.Rendering.GraphicsJobsSyncPoint : System.Enum
---@field public EndOfFrame UnityEngine.Experimental.Rendering.GraphicsJobsSyncPoint @static
---@field public AfterScriptUpdate UnityEngine.Experimental.Rendering.GraphicsJobsSyncPoint @static
---@field public AfterScriptLateUpdate UnityEngine.Experimental.Rendering.GraphicsJobsSyncPoint @static
---@field public WaitForPresent UnityEngine.Experimental.Rendering.GraphicsJobsSyncPoint @static
---@field public value__ number
local m = {}

UnityEngine.Experimental.Rendering.GraphicsJobsSyncPoint = m
return m
