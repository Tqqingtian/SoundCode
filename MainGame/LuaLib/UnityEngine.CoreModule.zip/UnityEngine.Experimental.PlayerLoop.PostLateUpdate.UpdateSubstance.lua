---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateSubstance : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateSubstance = m
return m
