---@class UnityEngine.Experimental.PlayerLoop.PreLateUpdate.UpdateMasterServerInterface : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreLateUpdate.UpdateMasterServerInterface = m
return m
