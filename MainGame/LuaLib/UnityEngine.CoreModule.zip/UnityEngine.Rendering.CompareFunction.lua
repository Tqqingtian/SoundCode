---@class UnityEngine.Rendering.CompareFunction : System.Enum
---@field public Disabled UnityEngine.Rendering.CompareFunction @static
---@field public Never UnityEngine.Rendering.CompareFunction @static
---@field public Less UnityEngine.Rendering.CompareFunction @static
---@field public Equal UnityEngine.Rendering.CompareFunction @static
---@field public LessEqual UnityEngine.Rendering.CompareFunction @static
---@field public Greater UnityEngine.Rendering.CompareFunction @static
---@field public NotEqual UnityEngine.Rendering.CompareFunction @static
---@field public GreaterEqual UnityEngine.Rendering.CompareFunction @static
---@field public Always UnityEngine.Rendering.CompareFunction @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.CompareFunction = m
return m
