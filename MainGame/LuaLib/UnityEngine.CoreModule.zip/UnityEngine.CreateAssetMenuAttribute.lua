---@class UnityEngine.CreateAssetMenuAttribute : System.Attribute
---@field public menuName string
---@field public fileName string
---@field public order number
local m = {}

UnityEngine.CreateAssetMenuAttribute = m
return m
