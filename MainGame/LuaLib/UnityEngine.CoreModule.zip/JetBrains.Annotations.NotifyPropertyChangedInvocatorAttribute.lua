---@class JetBrains.Annotations.NotifyPropertyChangedInvocatorAttribute : System.Attribute
---@field public ParameterName string
local m = {}

JetBrains.Annotations.NotifyPropertyChangedInvocatorAttribute = m
return m
