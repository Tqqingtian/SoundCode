---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.EndGraphicsJobsAfterScriptLateUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.EndGraphicsJobsAfterScriptLateUpdate = m
return m
