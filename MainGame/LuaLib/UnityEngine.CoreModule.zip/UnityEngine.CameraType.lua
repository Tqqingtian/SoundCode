---@class UnityEngine.CameraType : System.Enum
---@field public Game UnityEngine.CameraType @static
---@field public SceneView UnityEngine.CameraType @static
---@field public Preview UnityEngine.CameraType @static
---@field public VR UnityEngine.CameraType @static
---@field public Reflection UnityEngine.CameraType @static
---@field public value__ number
local m = {}

UnityEngine.CameraType = m
return m
