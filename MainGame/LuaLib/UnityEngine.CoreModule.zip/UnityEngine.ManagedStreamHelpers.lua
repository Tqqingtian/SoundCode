---@class UnityEngine.ManagedStreamHelpers : System.Object
local m = {}

UnityEngine.ManagedStreamHelpers = m
return m
