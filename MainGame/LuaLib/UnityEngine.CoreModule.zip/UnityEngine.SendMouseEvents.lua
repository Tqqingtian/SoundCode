---@class UnityEngine.SendMouseEvents : System.Object
local m = {}

UnityEngine.SendMouseEvents = m
return m
