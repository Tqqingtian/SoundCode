---@class UnityEngine.Rendering.VertexAttribute : System.Enum
---@field public Position UnityEngine.Rendering.VertexAttribute @static
---@field public Normal UnityEngine.Rendering.VertexAttribute @static
---@field public Tangent UnityEngine.Rendering.VertexAttribute @static
---@field public Color UnityEngine.Rendering.VertexAttribute @static
---@field public TexCoord0 UnityEngine.Rendering.VertexAttribute @static
---@field public TexCoord1 UnityEngine.Rendering.VertexAttribute @static
---@field public TexCoord2 UnityEngine.Rendering.VertexAttribute @static
---@field public TexCoord3 UnityEngine.Rendering.VertexAttribute @static
---@field public TexCoord4 UnityEngine.Rendering.VertexAttribute @static
---@field public TexCoord5 UnityEngine.Rendering.VertexAttribute @static
---@field public TexCoord6 UnityEngine.Rendering.VertexAttribute @static
---@field public TexCoord7 UnityEngine.Rendering.VertexAttribute @static
---@field public BlendWeight UnityEngine.Rendering.VertexAttribute @static
---@field public BlendIndices UnityEngine.Rendering.VertexAttribute @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.VertexAttribute = m
return m
