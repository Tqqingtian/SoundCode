---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.PlayerSendFrameComplete : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.PlayerSendFrameComplete = m
return m
