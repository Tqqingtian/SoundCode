---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.PhysicsResetInterpolatedTransformPosition : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.PhysicsResetInterpolatedTransformPosition = m
return m
