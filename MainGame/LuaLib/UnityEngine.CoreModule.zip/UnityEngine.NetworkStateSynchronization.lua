---@class UnityEngine.NetworkStateSynchronization : System.Enum
---@field public value__ number
local m = {}

UnityEngine.NetworkStateSynchronization = m
return m
