---@class UnityEngine.FullScreenMovieScalingMode : System.Enum
---@field public None UnityEngine.FullScreenMovieScalingMode @static
---@field public AspectFit UnityEngine.FullScreenMovieScalingMode @static
---@field public AspectFill UnityEngine.FullScreenMovieScalingMode @static
---@field public Fill UnityEngine.FullScreenMovieScalingMode @static
---@field public value__ number
local m = {}

UnityEngine.FullScreenMovieScalingMode = m
return m
