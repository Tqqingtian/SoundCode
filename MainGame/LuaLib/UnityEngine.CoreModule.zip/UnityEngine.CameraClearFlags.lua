---@class UnityEngine.CameraClearFlags : System.Enum
---@field public Skybox UnityEngine.CameraClearFlags @static
---@field public Color UnityEngine.CameraClearFlags @static
---@field public SolidColor UnityEngine.CameraClearFlags @static
---@field public Depth UnityEngine.CameraClearFlags @static
---@field public Nothing UnityEngine.CameraClearFlags @static
---@field public value__ number
local m = {}

UnityEngine.CameraClearFlags = m
return m
