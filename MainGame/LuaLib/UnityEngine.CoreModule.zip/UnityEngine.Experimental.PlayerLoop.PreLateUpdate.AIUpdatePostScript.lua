---@class UnityEngine.Experimental.PlayerLoop.PreLateUpdate.AIUpdatePostScript : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreLateUpdate.AIUpdatePostScript = m
return m
