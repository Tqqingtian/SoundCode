---@class UnityEngine.Camera.GateFitParameters : System.ValueType
---@field public mode UnityEngine.Camera.GateFitMode
---@field public aspect number
local m = {}

UnityEngine.Camera.GateFitParameters = m
return m
