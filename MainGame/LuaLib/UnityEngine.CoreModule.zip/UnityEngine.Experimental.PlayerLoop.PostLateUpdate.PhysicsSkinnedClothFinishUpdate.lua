---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.PhysicsSkinnedClothFinishUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.PhysicsSkinnedClothFinishUpdate = m
return m
