---@class JetBrains.Annotations.NotNullAttribute : System.Attribute
local m = {}

JetBrains.Annotations.NotNullAttribute = m
return m
