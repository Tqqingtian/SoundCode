---@class UnityEngine.Experimental.PlayerLoop.FixedUpdate.NewInputFixedUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.FixedUpdate.NewInputFixedUpdate = m
return m
