---@class UnityEngine.Rendering.CopyTextureSupport : System.Enum
---@field public None UnityEngine.Rendering.CopyTextureSupport @static
---@field public Basic UnityEngine.Rendering.CopyTextureSupport @static
---@field public Copy3D UnityEngine.Rendering.CopyTextureSupport @static
---@field public DifferentTypes UnityEngine.Rendering.CopyTextureSupport @static
---@field public TextureToRT UnityEngine.Rendering.CopyTextureSupport @static
---@field public RTToTexture UnityEngine.Rendering.CopyTextureSupport @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.CopyTextureSupport = m
return m
