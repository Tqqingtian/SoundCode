---@class UnityEngine.LightmapsMode : System.Enum
---@field public NonDirectional UnityEngine.LightmapsMode @static
---@field public CombinedDirectional UnityEngine.LightmapsMode @static
---@field public SeparateDirectional UnityEngine.LightmapsMode @static
---@field public Single UnityEngine.LightmapsMode @static
---@field public Dual UnityEngine.LightmapsMode @static
---@field public Directional UnityEngine.LightmapsMode @static
---@field public value__ number
local m = {}

UnityEngine.LightmapsMode = m
return m
