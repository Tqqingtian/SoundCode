---@class UnityEngine.Rendering.BuiltinShaderMode : System.Enum
---@field public Disabled UnityEngine.Rendering.BuiltinShaderMode @static
---@field public UseBuiltin UnityEngine.Rendering.BuiltinShaderMode @static
---@field public UseCustom UnityEngine.Rendering.BuiltinShaderMode @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.BuiltinShaderMode = m
return m
