---@class JetBrains.Annotations.StringFormatMethodAttribute : System.Attribute
---@field public FormatParameterName string
local m = {}

JetBrains.Annotations.StringFormatMethodAttribute = m
return m
