---@class UnityEngine.Experimental.PlayerLoop.FixedUpdate.PhysicsFixedUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.FixedUpdate.PhysicsFixedUpdate = m
return m
