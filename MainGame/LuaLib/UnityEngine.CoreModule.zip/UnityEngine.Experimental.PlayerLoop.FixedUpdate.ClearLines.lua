---@class UnityEngine.Experimental.PlayerLoop.FixedUpdate.ClearLines : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.FixedUpdate.ClearLines = m
return m
