---@class UnityEngine.RenderingPath : System.Enum
---@field public UsePlayerSettings UnityEngine.RenderingPath @static
---@field public VertexLit UnityEngine.RenderingPath @static
---@field public Forward UnityEngine.RenderingPath @static
---@field public DeferredLighting UnityEngine.RenderingPath @static
---@field public DeferredShading UnityEngine.RenderingPath @static
---@field public value__ number
local m = {}

UnityEngine.RenderingPath = m
return m
