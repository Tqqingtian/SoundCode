---@class UnityEngine.Compass : System.Object
---@field public magneticHeading number
---@field public trueHeading number
---@field public headingAccuracy number
---@field public rawVector UnityEngine.Vector3
---@field public timestamp number
---@field public enabled boolean
local m = {}

UnityEngine.Compass = m
return m
