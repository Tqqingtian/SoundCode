---@class UnityEngine.Rendering.OpaqueSortMode : System.Enum
---@field public Default UnityEngine.Rendering.OpaqueSortMode @static
---@field public FrontToBack UnityEngine.Rendering.OpaqueSortMode @static
---@field public NoDistanceSort UnityEngine.Rendering.OpaqueSortMode @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.OpaqueSortMode = m
return m
