---@class Unity.Collections.LowLevel.Unsafe.AtomicSafetyHandleVersionMask : System.Enum
---@field public Read Unity.Collections.LowLevel.Unsafe.AtomicSafetyHandleVersionMask @static
---@field public Write Unity.Collections.LowLevel.Unsafe.AtomicSafetyHandleVersionMask @static
---@field public Dispose Unity.Collections.LowLevel.Unsafe.AtomicSafetyHandleVersionMask @static
---@field public ReadAndWrite Unity.Collections.LowLevel.Unsafe.AtomicSafetyHandleVersionMask @static
---@field public ReadWriteAndDispose Unity.Collections.LowLevel.Unsafe.AtomicSafetyHandleVersionMask @static
---@field public WriteInv Unity.Collections.LowLevel.Unsafe.AtomicSafetyHandleVersionMask @static
---@field public ReadInv Unity.Collections.LowLevel.Unsafe.AtomicSafetyHandleVersionMask @static
---@field public ReadAndWriteInv Unity.Collections.LowLevel.Unsafe.AtomicSafetyHandleVersionMask @static
---@field public ReadWriteAndDisposeInv Unity.Collections.LowLevel.Unsafe.AtomicSafetyHandleVersionMask @static
---@field public value__ number
local m = {}

Unity.Collections.LowLevel.Unsafe.AtomicSafetyHandleVersionMask = m
return m
