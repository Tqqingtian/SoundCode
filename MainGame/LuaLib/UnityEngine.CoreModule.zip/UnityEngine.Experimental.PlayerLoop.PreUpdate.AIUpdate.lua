---@class UnityEngine.Experimental.PlayerLoop.PreUpdate.AIUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreUpdate.AIUpdate = m
return m
