---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UpdateAsyncReadbackManager : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UpdateAsyncReadbackManager = m
return m
