---@class UnityEngine.Rendering.ShadowSamplingMode : System.Enum
---@field public CompareDepths UnityEngine.Rendering.ShadowSamplingMode @static
---@field public RawDepth UnityEngine.Rendering.ShadowSamplingMode @static
---@field public None UnityEngine.Rendering.ShadowSamplingMode @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.ShadowSamplingMode = m
return m
