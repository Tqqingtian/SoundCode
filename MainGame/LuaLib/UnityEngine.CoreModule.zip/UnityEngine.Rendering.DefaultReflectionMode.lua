---@class UnityEngine.Rendering.DefaultReflectionMode : System.Enum
---@field public Skybox UnityEngine.Rendering.DefaultReflectionMode @static
---@field public Custom UnityEngine.Rendering.DefaultReflectionMode @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.DefaultReflectionMode = m
return m
