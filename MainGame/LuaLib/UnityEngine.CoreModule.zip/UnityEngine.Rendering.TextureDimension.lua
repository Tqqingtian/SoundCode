---@class UnityEngine.Rendering.TextureDimension : System.Enum
---@field public Unknown UnityEngine.Rendering.TextureDimension @static
---@field public None UnityEngine.Rendering.TextureDimension @static
---@field public Any UnityEngine.Rendering.TextureDimension @static
---@field public Tex2D UnityEngine.Rendering.TextureDimension @static
---@field public Tex3D UnityEngine.Rendering.TextureDimension @static
---@field public Cube UnityEngine.Rendering.TextureDimension @static
---@field public Tex2DArray UnityEngine.Rendering.TextureDimension @static
---@field public CubeArray UnityEngine.Rendering.TextureDimension @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.TextureDimension = m
return m
