---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.MemoryFrameMaintenance : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.MemoryFrameMaintenance = m
return m
